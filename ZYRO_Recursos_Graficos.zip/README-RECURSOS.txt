ZYRO — PAQUETE INICIAL DE RECURSOS GRÁFICOS
================================================

DÓNDE EXTRAER
-------------
Extrae el ZIP en la carpeta raíz del proyecto Laravel, donde están:
artisan, composer.json, app/, routes/, resources/ y public/.

El ZIP crea/combina la ruta public/images/ dentro del proyecto.
No reemplaces ni elimines carpetas completas.

CONTENIDO
---------
- public/images/products/: cinco composiciones de chompas facilitadas.
- public/images/technology/: ilustración explicativa del concepto tecnológico.
- public/images/banners/: captura de referencia visual para orientar el rediseño.

IMPORTANTE
----------
1. Las imágenes se copiaron tal como fueron proporcionadas.
2. La captura de referencia es guía de diseño; no se debe mostrar como una
   página funcional ni usar como banner final sin recortar/preparar.
3. Las composiciones de producto muestran vistas frontal/trasera juntas y
   no cubren por separado los ocho diseños acordados. El agente debe asignar
   imágenes con criterio y señalar qué recursos faltan, sin inventarlos.
4. No se proporcionó un archivo independiente del logo. Revisa si ya existe
   en el repositorio. Si no existe, solicita el archivo original o usa un
   espacio provisional claramente identificado; no afirmes que el logo real
   fue integrado.
5. Revisa las rutas y nombres antes de modificar Blade o la base de datos.
